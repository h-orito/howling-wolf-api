CREATE TABLE BLACKLIST_PLAYER
(
    BLACKLIST_PLAYER_ID INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ブラックリストプレイヤーID',
    FROM_PLAYER_ID      INT UNSIGNED NOT NULL COMMENT 'プレイヤーID',
    TO_PLAYER_ID        INT UNSIGNED NOT NULL COMMENT 'ブラックリスト対象プレイヤーID',
    REGISTER_DATETIME   DATETIME    NOT NULL COMMENT '登録日時',
    REGISTER_TRACE      VARCHAR(64) NOT NULL COMMENT '登録トレース',
    UPDATE_DATETIME     DATETIME    NOT NULL COMMENT '更新日時',
    UPDATE_TRACE        VARCHAR(64) NOT NULL COMMENT '更新トレース',
    PRIMARY KEY (BLACKLIST_PLAYER_ID),
    CONSTRAINT UQ_blacklist_player UNIQUE (FROM_PLAYER_ID, TO_PLAYER_ID)
) COMMENT = 'ブラックリストプレイヤー';

ALTER TABLE BLACKLIST_PLAYER
    ADD CONSTRAINT FK_BLACKLIST_PLAYER_PLAYER FOREIGN KEY (FROM_PLAYER_ID)
        REFERENCES PLAYER (PLAYER_ID)
        ON UPDATE RESTRICT
        ON DELETE RESTRICT
;


ALTER TABLE BLACKLIST_PLAYER
    ADD CONSTRAINT FK_BLACKLIST_TO_PLAYER_PLAYER FOREIGN KEY (TO_PLAYER_ID)
        REFERENCES PLAYER (PLAYER_ID)
        ON UPDATE RESTRICT
        ON DELETE RESTRICT
;

drop table RESERVED_VILLAGE;

CREATE TABLE AUTOGENERATE_ORGANIZE
(
    VILLAGE_ID_MOD           INT          NOT NULL COMMENT '余り',
    ORGANIZATION             VARCHAR(255) NOT NULL COMMENT '編成',
    IS_AVAILABLE_DUMMY_SKILL BOOLEAN      NOT NULL COMMENT '役欠けありか',
    REGISTER_DATETIME        DATETIME     NOT NULL COMMENT '登録日時',
    REGISTER_TRACE           VARCHAR(64)  NOT NULL COMMENT '登録トレース',
    UPDATE_DATETIME          DATETIME     NOT NULL COMMENT '更新日時',
    UPDATE_TRACE             VARCHAR(64)  NOT NULL COMMENT '更新トレース',
    PRIMARY KEY (VILLAGE_ID_MOD)
) COMMENT = '自動生成編成';


CREATE TABLE AUTOGENERATE_TIME
(
    VILLAGE_ID_MOD    INT         NOT NULL COMMENT '余り',
    START_TIME        CHAR(4)     NOT NULL COMMENT '開始時間',
    SILENT_HOURS      INT UNSIGNED NOT NULL COMMENT '沈黙時間',
    REGISTER_DATETIME DATETIME    NOT NULL COMMENT '登録日時',
    REGISTER_TRACE    VARCHAR(64) NOT NULL COMMENT '登録トレース',
    UPDATE_DATETIME   DATETIME    NOT NULL COMMENT '更新日時',
    UPDATE_TRACE      VARCHAR(64) NOT NULL COMMENT '更新トレース',
    PRIMARY KEY (VILLAGE_ID_MOD)
) COMMENT = '自動生成編成';


insert into AUTOGENERATE_ORGANIZE values (0, '狼狼狂占霊狩村村村村', 0, now(), 'ort', now(), 'ort');
insert into AUTOGENERATE_ORGANIZE values (1, '狼狼狼狂占霊狩村村村村村村村村村', 0, now(), 'ort', now(), 'ort');
insert into AUTOGENERATE_ORGANIZE values (2, '狼狼狼狂占霊狩村村村村村村', 0, now(), 'ort', now(), 'ort');
insert into AUTOGENERATE_ORGANIZE values (3, '狼狼狼狂占霊狩狐共共村村村村村村', 0, now(), 'ort', now(), 'ort');
insert into AUTOGENERATE_ORGANIZE values (4, '狼狼Ｃ占霊狩村村村村村村', 0, now(), 'ort', now(), 'ort');
insert into AUTOGENERATE_ORGANIZE values (5, '狼狼占村村村村村村', 0, now(), 'ort', now(), 'ort');
insert into AUTOGENERATE_ORGANIZE values (6, '狼狼狂占霊狩村村村村村', 0, now(), 'ort', now(), 'ort');
insert into AUTOGENERATE_ORGANIZE values (7, '狼狼狂占霊狩狐村村村村村', 1, now(), 'ort', now(), 'ort');
insert into AUTOGENERATE_ORGANIZE values (8, '狼狼占村村村村村', 0, now(), 'ort', now(), 'ort');
insert into AUTOGENERATE_ORGANIZE values (9, '狼狼狼狂占霊狩村村村村村村村', 0, now(), 'ort', now(), 'ort');


insert into AUTOGENERATE_TIME values (0, '0000', 7, now(), 'ort', now(), 'ort');
insert into AUTOGENERATE_TIME values (1, '0700', 0, now(), 'ort', now(), 'ort');
insert into AUTOGENERATE_TIME values (2, '2300', 8, now(), 'ort', now(), 'ort');
insert into AUTOGENERATE_TIME values (3, '0100', 0, now(), 'ort', now(), 'ort');
insert into AUTOGENERATE_TIME values (4, '0000', 0, now(), 'ort', now(), 'ort');
insert into AUTOGENERATE_TIME values (5, '0700', 10, now(), 'ort', now(), 'ort');
insert into AUTOGENERATE_TIME values (6, '2200', 0, now(), 'ort', now(), 'ort');
insert into AUTOGENERATE_TIME values (7, '0100', 6, now(), 'ort', now(), 'ort');
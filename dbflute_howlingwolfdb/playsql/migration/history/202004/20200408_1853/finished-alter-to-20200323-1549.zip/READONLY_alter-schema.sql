insert into SKILL values ('VILLAGERS', 'おまかせ（村人陣営）', 'お', 'VILLAGER', 8, '村人陣営の中で余った役職が割り当てられます。');
insert into SKILL values ('WEREWOLFS', 'おまかせ（人狼陣営）', 'お', 'VILLAGER', 9, '人狼陣営の中で余った役職が割り当てられます。');

begin;
update SKILL set disp_order = 1 where skill_code = 'VILLAGER';
update SKILL set disp_order = 2 where skill_code = 'SEER';
update SKILL set disp_order = 3 where skill_code = 'MEDIUM';
update SKILL set disp_order = 4 where skill_code = 'HUNTER';
update SKILL set disp_order = 5 where skill_code = 'WEREWOLF';
update SKILL set disp_order = 6 where skill_code = 'MADMAN';
update SKILL set disp_order = 7 where skill_code = 'LEFTOVER';
commit;
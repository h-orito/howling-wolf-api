alter table CAMP add column DISP_ORDER INT UNSIGNED NOT NULL COMMENT '並び順' after camp_code;

update CAMP set disp_order = 1 where camp_code = 'VILLAGER';
update CAMP set disp_order = 2 where camp_code = 'WEREWOLF';
update CAMP set disp_order = 3 where camp_code = 'FOX';

alter table MESSAGE add column MESSAGE_COUNT INT UNSIGNED COMMENT '何回目の発言か : その日のその発言種別において何回目の発言か' after message_datetime;

begin;
update MESSAGE set message_count = 1 where message_type_code in ('NORMAL_SAY', 'WEREWOLF_SAY', 'MONOLOGUE_SAY', 'MONOLOGUE_SAY', 'GRAVE_SAY');
commit;

alter table RESERVED_VILLAGE add column IS_FOR_BEGINNER BOOLEAN NOT NULL COMMENT '初心者村か' after IS_AVAILABLE_DUMMY_SKILL;

begin;
update RESERVED_VILLAGE set is_for_beginner = false;
insert into VILLAGE_SETTING_ITEM values ('is_for_beginner', '初心者村か', 20);
commit;


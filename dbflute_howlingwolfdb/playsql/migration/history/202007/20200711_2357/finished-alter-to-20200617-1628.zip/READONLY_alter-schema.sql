insert into VILLAGE_SETTING_ITEM values ('is_available_dummy_skill', '役欠けありか', 19);

alter table RESERVED_VILLAGE add column IS_AVAILABLE_DUMMY_SKILL BOOLEAN NOT NULL COMMENT '役欠けありか';
update RESERVED_VILLAGE set IS_AVAILABLE_DUMMY_SKILL = false;